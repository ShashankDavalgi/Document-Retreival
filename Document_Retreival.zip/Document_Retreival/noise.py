import cv2
import numpy as np
from os import listdir
from os.path import isfile,join
from matplotlib import pyplot as plt
from array import*
import os
mypath1='C:\Users\Kanka\Desktop\Signature_extraction'
length_folder=len(os.walk(mypath1).next()[1])
for fol in range(0,length_folder):
 mypath=mypath1+'\per_'+str(fol)
 print mypath
 images1= [ f for f in listdir(mypath) if isfile(join(mypath,f)) ]
 images = np.empty(len(images1), dtype=object)

 for n in range(0, len(images1)):
   images[n] = cv2.imread( join(mypath,images1[n]),0)
 ed=1
 for i in range(0,len(images1)):
     if i%10==0:
      ed=ed+1
      print 'fdfd',ed
     height,width=images[i].shape[:2]
     per=images[i][7:height-10,30:width-30]
     cv2.imshow('hey',per)
     cv2.waitKey(0)
     h_cut,w_cut=per.shape[:2]
     min=500000
     for k in range(0,h_cut):
       for j in range(0,w_cut):
        if per[k,j]==0:
           if j<min:
             min=j
        # print min
     first_y=min
     print first_y
     r_min=500000
     for k in range(0,h_cut):
       for j in range(0,w_cut):
         if per[k,j]==0:
       #print i
           if k<r_min:
            r_min=k
       # print r_min
     first_x=r_min
 
     max=0
     n=w_cut-1
     m=0
 #print w_cut
     for m in range(0,h_cut):
       for n in range(w_cut-1,0,-1):
     # print n
          if per[m,n]==0:
             if n>max:
              # print max
               max=n
     second_y=max

     r_max=0
     n=h_cut-1
     m=0
     for m in range(h_cut-1,0,-1):
       for n in range(0,w_cut):
         if per[m,n]==0:
           if m>r_max:
             r_max=m
        #print m
     second_x=r_max

     print first_x
     print second_x
     print first_y
     print second_y
     cut_img=per[first_x:second_x,first_y:second_y]
     dilation=cv2.resize(cut_img,(250,250),interpolation=cv2.INTER_CUBIC)
     folder ='C:\Users\Kanka\Desktop\signs\per_'+str(fol)
     if not os.path.isdir(folder):
      os.makedirs(folder)
     
     cv2.imwrite(folder+'\\'+str(ed)+str(i)+'.png',dilation)
     cv2.destroyAllWindows()
     print 'hey',str(m),str(i)
     kernel=np.ones((5,5),np.uint8)
     dilation=cv2.morphologyEx(dilation,cv2.MORPH_OPEN,kernel)   
   #  cv2.imshow('hey',dilation)
    # cv2.waitKey(0)
     blur = cv2.GaussianBlur(dilation,(5,5),0)
     median = cv2.medianBlur(blur,5)
     source=median
     final = source[:]
     for y in range(len(source)):
       for x in range(y):
           final[y,x]=source[y,x]
     members=[source[0,0]]*9
     for y in range(1,len(source)-1):
         for x in range(1,y-1):
             members[0] = source[y-1,x-1]
             members[1] = source[y,x-1]
             members[2] = source[y+1,x-1]
             members[3] = source[y-1,x]
             members[4] = source[y,x]
             members[5] = source[y+1,x]
             members[6] = source[y-1,x+1]
             members[7] = source[y,x+1]
             members[8] = source[y+1,x+1]

             members.sort()
             final[y,x]=members[4]
  #  cv2.imshow('final',final)
   # cv2.waitKey(0)
   
