import cv2
import numpy as np
from os import listdir
from os.path import isfile,join
from matplotlib import pyplot as plt
from array import*
surf = cv2.SURF(400)

mypath='C:\Users\Kanka\Desktop\signs'
images1= [ f for f in listdir(mypath) if isfile(join(mypath,f)) ]
images = np.empty(len(images1), dtype=object)
for n in range(0, len(images1)):
  images[n] = cv2.imread( join(mypath,images1[n]))

for i in range(0,len(images)):
    print '---------------------persion_',str(i),'-----'
    """gray = cv2.cvtColor(images[i],cv2.COLOR_BGR2GRAY)
    gray = np.float32(gray)
   # print gray
    dst = cv2.cornerHarris(gray,2,3,0.04)
    print len(dst)
    dst = cv2.dilate(dst,None)
  # Threshold for an optimal value, it may vary depending on the image.
    images[i][dst>0.01*dst.max()]=[0,0,255]
   
    cv2.imshow('dst',images[i])
    if cv2.waitKey(0) & 0xff == 27:
        cv2.destroyAllWindows()"""
    kp, des= surf.detectAndCompute(images[i],None)
    print len(kp)
    surf.hessianThreshold = 1000
    kp, des = surf.detectAndCompute(images[i],None)
    print len(kp)
    img3 = cv2.drawKeypoints(images[i],kp,None,(255,0,0),4)
  #  plt.imshow(img3),plt.show()
