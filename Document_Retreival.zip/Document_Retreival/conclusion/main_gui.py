import cv2
from Tkinter import *
from PIL import  ImageTk,Image
from tkFileDialog import  askopenfilename
class App:
    import Tkinter
    def __init__(self, master):
        frame = Frame(master)
        frame.pack()

        self.label = Label(frame,text="Document Image Retrieval using Signatures as Queries",font=("Arial",12,"bold"))
        self.label.pack()

        self.slogan = Button(frame,
                         text="Load a Document",
                         command=self.write_slogan)
        self.slogan.pack()

    def write_slogan(self):

        r = Image.open(askopenfilename(), 'r')
        image1 = r.resize((250, 250), Image.ANTIALIAS)
        image1 = ImageTk.PhotoImage(image1)

        # self.pw.pic = ImageTk.PhotoImage(image1)
        label = Label(image=image1)

        ##  p = QPixmap.grabWindow(label)
        # p.save(filename, 'jpg')
        label.image = image1  # keep a reference!
        label.pack()

        frame = Frame(root)
        frame.pack()

        self.slogan1 = Button(frame,
                              text="To extract Signatures",
                              command=self.callback)

        self.slogan1.pack()



    def callback(self):
        execfile("C:\Users\Kanka\Desktop\New folder (7)\sign_extract.py")
        img = ImageTk.PhotoImage(Image.open("C:\\Users\\Kanka\\Desktop\\New folder (7)\\signs\\tes0t\\test.png"))
      #img = img.resize((250, 250), Image.ANTIALIAS)
      #image1 = ImageTk.PhotoImage(im.,bdsg)

        panel = Label(root, image=img)
        panel.image = img
        panel.pack()


        frame1 = Frame(root)
        frame1.pack()

        self.slogan1 = Button(frame1,
                              text="Person",
                              command=self.identify)

        self.slogan1.pack()

    def identify(self):
       # print 'shshsh'
        execfile("C:\Users\Kanka\Desktop\New folder (7)\ecludian1.py")
        root.mainloop()


root = Tk()
root.title("Home Page")
root.geometry("500x900")
sc = Scrollbar(root)
sc.pack(side=RIGHT,fill=Y)
mylist = Listbox(root,yscrollcommand=sc.set)
for line in range(100):
    mylist.insert(END,"")
    mylist.pack(side=LEFT,fill=BOTH)
    sc.config(command=mylist.yview)
app = App(root)
root.mainloop()
