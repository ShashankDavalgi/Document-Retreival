import cv2
import numpy as np
import time
from matplotlib import pyplot as plt
from os import listdir
import os
from os.path import isfile,join
from array import*
mypath='C:\Users\Kanka\Desktop\New folder (7)\Person'
Person= [ f for f in listdir(mypath) if isfile(join(mypath,f)) ]
images = np.empty(len(Person), dtype=object)
for n in range(0, len(Person)):
  images[n] = cv2.imread( join(mypath,Person[n]),0)
#for n in range(0,len(Person)):
 #   cv2.imshow('Total_images',images[n])
  #  cv2.waitKey(0)

#res = np.empty(len(images), dtype=object)
#per_det = np.empty(len(images), dtype=object)
#per_sign = np.empty(len(images), dtype=object)
#per_sign1= np.empty(len(images), dtype=object)
for i in range (0,len(images)):
    height,width=images[i].shape[:2]
    print height,':',width
    res=cv2.resize(images[i],(650,650),interpolation=cv2.INTER_CUBIC)
    #cv2.imshow('Total_images',res)
    cv2.waitKey(0)
    height,width=res.shape[:2]
   
    r_min=241
   # cv2.imshow('total_images',res)
    cv2.waitKey(0)
    per_det=res[0:r_min,0:width]
    per_sign=res[r_min:height,0:width]
    #cv2.imshow('person_details',per_det)
    cv2.waitKey(0)
    cv2.imwrite('C:\Users\Kanka\Desktop\New folder (7)\per_det\per_'+str(i)+'.jpg',per_det)
    cv2.destroyAllWindows()
    #cv2.imshow('person_signature',per_sign)
    cv2.waitKey(0)
    height,width=per_sign.shape[:2]
    per_sign=per_sign[0:height-100,80:width-100]
    height,width=per_sign.shape[:2]
    per_sign1=per_sign[0:height,width/2:width]
    per_sign=per_sign[0:height,0:width/2]
    #cv2.imshow('person_signature',per_sign1)
    cv2.waitKey(0)
    #cv2.imshow('person_signature',per_sign)
    cv2.waitKey(0)
    height,width=per_sign.shape[:2]
    #per_sign1=per_sign1[0:height-100,0:width-100]
    #per_sign=per_sign[0:height-100,90:width]
    height,width=per_sign1.shape[:2]
    height1,width1=per_sign.shape[:2]
    for j in range(0,5):
      sign=per_sign1[j*height/5:(j+1)*height/5,0:width]
      sign1=per_sign[j*height1/5:(j+1)*height1/5,0:width1]
      thresh=200
      maxvalue=500
      th,sign=cv2.threshold(sign,thresh,maxvalue,cv2.THRESH_BINARY);
      th,sign1=cv2.threshold(sign1,thresh,maxvalue,cv2.THRESH_BINARY);
      #cv2.imshow("ran",sign)
      cv2.waitKey(0)
      folder ='C:\Users\Kanka\Desktop\New folder (7)\Signature_extraction\per_'+str(i)
      if not os.path.isdir(folder):
        os.makedirs(folder)
      cv2.imwrite(folder+'\per_'+str(i)+'_sign'+str(j+1)+'.jpg',sign)
      cv2.destroyAllWindows()
      #cv2.imshow("ranbg",sign1)
      cv2.waitKey(0)
      folder ='C:\Users\Kanka\Desktop\New folder (7)\Signature_extraction\per_'+str(i)
      if not os.path.isdir(folder):
        os.makedirs(folder)
      cv2.imwrite(folder+'\per_'+str(i)+'_sign'+str(j+6)+'.jpg',sign1)
      cv2.destroyAllWindows()
    #cv2.imshow('person_signature',per_sign1)
    #cv2.waitKey(0)
    #cv2.imshow('person_signature',per_sign)
    #cv2.waitKey(0)
           
 


