import cv2
import numpy as np
from os import listdir
from os.path import isfile,join
from matplotlib import pyplot as plt
from array import*
import os
mypath2='C:\Users\Kanka\Desktop\New folder (7)\signs'
length_folder=len(os.walk(mypath2).next()[1])
print length_folder
for fol in range(0,length_folder-1):
 no_of_true=0
 print 'the person no is',fol
 mypath=mypath2+'\per_'+str(fol)
 print mypath
#mypath='C:\Users\Mahantesh\Desktop\signs'
 images1= [ f for f in listdir(mypath) if isfile(join(mypath,f)) ]
 images = np.empty(len(images1), dtype=object)
 for n in range(0, len(images1)):
   images[n] = cv2.imread( join(mypath,images1[n]),0)


#img=cv2.imread('20.png',0)
#cv2.imshow("sdadada",img)
#cv2.waitKey(0)
   img=images[n]
   height,width=img.shape[:2]
   cnt = 0
   for i in range(0,height):
    for j in range(0,width-1):
       if img[i][j]==0:
          if img[i][j+1]!=0:
              cnt=cnt+1
              cv2.circle(img,(i,j),10,(0,0,0))

     #cv2.circle(img, img[i][j],5, (0,255,0)[5[ [0]]])
   print cnt
   cv2.imshow("dasa", img)
   cv2.waitKey(0)
#img3 = cv2.drawKeypoints(images[n], kp, None, (255, 0, 0), 4)