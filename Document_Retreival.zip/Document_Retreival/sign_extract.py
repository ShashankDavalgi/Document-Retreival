import cv2
import numpy as np
import time
#from matplotlib import pyplot as plt
from os import listdir
import os
from os.path import isfile,join
from array import*
mypath='C:\Users\Kanka\Desktop\New folder (7)\Signs_docs'
Person= [ f for f in listdir(mypath) if isfile(join(mypath,f)) ]
images = np.empty(len(Person), dtype=object)
for n in range(0, len(Person)):
  images[n] = cv2.imread( join(mypath,Person[n]),0)
  #cv2.imshow("hdas",images[n])
  #cv2.waitKey(0)
for i in range(0,len(images)):
    res = cv2.resize(images[i], (720, 720), interpolation=cv2.INTER_CUBIC)
#    cv2.imshow("sddsd",images[i])
  #  cv2.waitKey(0)
    height,width=res.shape[:2]
    res = res[3*height/4:height, 0:width]
    thresh = 200
    maxvalue = 500
    th, res = cv2.threshold(res, thresh, maxvalue, cv2.THRESH_BINARY);
  #  cv2.imshow("Sdsad",res)
  #  cv2.waitKey(0)
    h_cut, w_cut = res.shape[:2]
    min = 500000
    for k in range(0, h_cut):
        for j in range(0, w_cut):
          # print res[k,j]
           if res[k, j] == 0:
                if j < min:
                    min = j
                    print min

    first_y = min
    print first_y
    r_min = 500000
    for k in range(0, h_cut):
        for j in range(0, w_cut):
            if res[k, j] == 0:
                # print i
                if k < r_min:
                    r_min = k
                    # print r_min
    first_x = r_min

    max = 0
    n = w_cut - 1
    m = 0
    # print w_cut
    for m in range(0, h_cut):
        for n in range(w_cut - 1, 0, -1):
            # print n
            if res[m, n] == 0:
                if n > max:
                    # print max
                    max = n
    second_y = max

    r_max = 0
    n = h_cut - 1
    m = 0
    for m in range(h_cut - 1, 0, -1):
        for n in range(0, w_cut):
            if res[m, n] == 0:
                if m > r_max:
                    r_max = m
                    # print m
    second_x = r_max

    print first_x
    print second_x
    print first_y
    print second_y
    cut_img = res[first_x:second_x, first_y:second_y]
   # cv2.imshow("sdasda",cut_img)
   # cv2.waitKey(0)
    dilation = cv2.resize(cut_img, (250, 250), interpolation=cv2.INTER_CUBIC)
  #  cv2.imshow("sdadsada",dilation)
   # cv2.waitKey(0)
    cv2.imwrite('C:\\Users\\Kanka\\Desktop\\New folder (7)\\signs\\test\\test.png',dilation)
    cv2.destroyAllWindows()
