import Tkinter as tk
from PIL import Image, ImageTk
import os, tkFileDialog


button_flag = True

def click():
    global button_flag
    if button_flag:
        button1.config(bg="white")
        button_flag = False
    else:
        button1.config(bg="green")
        button_flag = True

root = tk.Tk()

frame1 = tk.Frame(root)
frame1.pack(side=tk.TOP, fill=tk.X)

image1 = Image.open(tkFileDialog.askopenfilename())
image1 = ImageTk.PhotoImage(image1)
button1 = tk.Button(frame1, compound=tk.TOP, width=155, height=55, image=image1, text="optional tet", bg='green', command=click)
button1.pack(side=tk.LEFT, padx=2, pady=2)

button1.image = image1

root.mainloop()
