import cv2
import numpy as np
from os import listdir
from os.path import isfile, join
#from matplotlib import pyplot as plt
#from scipy.spatial import distance
from array import *
import os

img_test = cv2.imread('C:\\Users\\Kanka\\Desktop\\New folder (7)\\signs\\test\\test.png', 0)
#img_test = cv2.imread('20.png',0);

ty = 0
Ly2 = []
Ly=[]
for j in range(0, 250):
    for k in range(0, 250):
        # if img_test[j][k]==0:
        Ly.insert(ty, img_test[j][k])
        ty = ty + 1
        if ty > 1:
         Ly2.insert(ty - 1, img_test[j][k])
sum_test = 0
for j in range(0, ty - 2, 2):
        dist_x = Ly[j] - Ly2[j + 1]
        dist_y = Ly[j + 1] - Ly2[j + 2]
        dist_x = dist_x * dist_x
        dist_y = dist_y * dist_y
        temp = dist_x + dist_y
        ecludian_value = temp ** (.5)
        sum_test= sum_test + ecludian_value
            # print ecludian_value
sum_test+=10000
print 'test_sum is',sum_test

# print len(Ly)
# print Ly
tot_avg=0
mypath2 = 'C:\Users\Kanka\Desktop\New folder (7)\signs'
length_folder = len(os.walk(mypath2).next()[1])

trues = np.empty(length_folder, dtype=object)
for kol in range(0,len(trues)):
    trues[kol]=0
#print length_folder
for fol in range(0, length_folder - 1):
    tot_avg = tot_avg / 9
    print "tot_avg:",tot_avg
	
    #if sum_test+2000>tot_avg and sum_test-2000<tot_avg:
      # print 'true'
   # print tot_avg,'tot_avg'
    tot_avg = 0
  #  print 'fol#der no is', fol
    total_sum = 0
    no_of_true = 0
    # print 'the person no is',fol
    mypath = mypath2 + '\per_' + str(fol)
    print mypath
    # mypath='C:\\Users\\Mahantesh\\Desktop\\signs\\test'
    images1 = [f for f in listdir(mypath) if isfile(join(mypath, f))]
    images = np.empty(len(images1), dtype=object)
    avg = np.empty(9, dtype=object)
    for n in range(0, len(images1)):
        images[n] = cv2.imread(join(mypath, images1[n]), 0)
        # for n in range(0,len(images)):
        # cv2.imshow("hari",images[n])
        # cv2.waitKey(0)

    for i in range(0, len(images)):
        tx = 0
        Lx = []
        Lx2=[]
        for j in range(0, 250):
            for k in range(0, 250):
                Lx.insert(tx, images[i][j][k])
                tx = tx + 1
                if tx>1:
                 Lx2.insert(tx-1,images[i][j][k])
   # print Lx,Lx2
        #print Lx
        #print Lx2
       # print tx
        sum=0
        for j in range(0,tx-2,2):
            dist_x=Lx[j]-Lx2[j+1]
            dist_y=Lx[j+1]-Lx2[j+2]
            dist_x=dist_x*dist_x
            dist_y=dist_y*dist_y
            temp=dist_x+dist_y
            ecludian_value=temp**(.5)
            sum=sum+ecludian_value
            # print ecludian_value
            #print sum
			
        tot_avg=tot_avg+sum
		
        if sum>sum_test-3000 and sum<sum_test+2000:
           # print 'true'
            temp=trues[fol]
            temp=temp+1
            trues[fol]=temp
	
#for k in range(0,len(trues)):
   # print trues[k]
maz=max(trues)
for k in range(0,len(trues)):
    if trues[k]== maz:
        final_person=k
        print k
        break
finall_pereson=cv2.imread('C:\Users\Kanka\Desktop\New folder (7)\per_det\per_'+str(final_person)+'.jpg',0)
cv2.imshow("final_person",finall_pereson)
cv2.waitKey(0)
