import cv2
import numpy as np
from os import listdir
from os.path import isfile,join
from matplotlib import pyplot as plt
from array import*
import os 
mypath2='C:\Users\Kanka\Desktop\signs'
length_folder=len(os.walk(mypath2).next()[1])
print length_folder
for fol in range(0,length_folder-1):
    no_of_true=0
    print 'the person no is',fol
    mypath=mypath2+'\per_'+str(fol)
    print mypath
#mypath='C:\Users\Kanka\Desktop\signs'
    images1= [ f for f in listdir(mypath) if isfile(join(mypath,f)) ]
    images = np.empty(len(images1), dtype=object)
    for n in range(0, len(images1)):
        images[n] = cv2.imread(join(mypath,images1[n]),0)


    mypath1='C:\\Users\\Kanka\\Desktop\\signs\\test'

    test_images1 = [ f for f in listdir(mypath1) if isfile(join(mypath1,f)) ]
    test_image = np.empty(len(test_images1), dtype=object)
    for n in range(0,len(test_images1)) :
        test_image[n]= cv2.imread( join(mypath1,test_images1[n]),0)
#for n in range(0,len(test_images1)) :
#cv2.imshow('kdlsd',test_image[0])
#cv2.waitKey(0)
        test_image=test_image[0]

        values1= np.empty(25, dtype=object)
        t=0
        tot1=0
        cnt1=0
        l=0
        for j in range(0,250,50):
             for k in range(0,250,50):
                per1=test_image[j:j+50,k:k+50]
        #cv2.imshow('sld',per)
        #cv2.waitKey(0)
        cnt1=0
       # for t in range(0,25):
        for r in range(0,50):
          for m in range(0,50):
            if per1[r,m]==0:
              cnt1=cnt1+1
              #print cnt1
     
		# print cnt1
        values1[l]=cnt1
        #print t,cnt1,values1[t]
        l=l+1
		# print values1[t]
for v in range(0,25):
	tot1=tot1+values1[v]
  # print tot1
tot1=tot1/25
print 'average of testing image',tot1
"""--------set of images extracting code here--------"""
values = np.empty(25, dtype=object)
for i in range(0,len(images1)):
    t=0
    tot=0
    for j in range(0,250,50):
		for k in range(0,250,50):
			per=images[i][j:j+50,k:k+50]
			#cv2.imshow('sld',per)
			#cv2.waitKey(0)
			cnt=0
			# for t in range(0,25):
			for r in range(0,50):
				for m in range(0,50):
					if per[r,m]==0:
						cnt=cnt+1
			# print cnt
			if t==25:
				t=0
			values[t]=cnt
			t=t+1
    for v in range(0,25):
		tot=tot+values[v]
    tot=tot/25
    #print tot
    if tot<=tot1+10 and tot>=tot1-10:
		print "true"
		no_of_true=no_of_true+1
    else:
		print "false",tot
print 'no of matching',no_of_true    
accuracy=no_of_true*100/10
print 'accuracy is',accuracy
